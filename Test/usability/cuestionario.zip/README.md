# Demo del frontend

Todos los botones estan mockeados y funcionan. POR FAVOR ir por el camino de registro primero, la lectura del tutorial al crear la cuenta es intencionada

Se presenta a continuación una demo del frontend. Si has descargado esta carpeta es porque vas a ejecutar el fichero

Solo testeado en Ubuntu.

Para instalar las dependencias

```sh
pip install .
```

Para ejecutar la deamo

```sh
# Dar permisos de ejecución
./run.sh
```

Por favor, responder las preguntas dispuestas en el cuestionario con el que se ha entregado este fichero. No lleva mucho tiempo :D.