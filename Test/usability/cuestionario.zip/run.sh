#!/bin/bash

streamlit run mocked_index.py